/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator.model;

/**
 *
 * @author Jayuk
 */
public class Kalkulator 
{
    public int buttonOne()
    {
        return 1;
    }
    public int buttonTwo()
    {
        return 2;
    }
    public int buttonThree()
    {
        return 3;
    }
    public int buttonFour()
    {
        return 4;
    }
    public int buttonFive()
    {
        return 5;
    }
    public int buttonSix()
    {
        return 6;
    }
    public int buttonSeven()
    {
        return 7;
    }
    public int buttonEight()
    {
        return 8;
    }
    public int buttonNine()
    {
        return 9;
    }
    public int buttonZero()
    {
        return 0;
    }
    
            
}
