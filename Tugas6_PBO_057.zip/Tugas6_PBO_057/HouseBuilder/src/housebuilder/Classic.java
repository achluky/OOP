package housebuilder;

/**
 *
 * @author Jayuk
 */
public class Classic implements Jenis
{

    @Override
    public String jenis() 
    {
        return "Classic";
    }
    
}
