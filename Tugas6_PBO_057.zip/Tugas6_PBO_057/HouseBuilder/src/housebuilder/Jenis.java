package housebuilder;

/**
 *
 * @author Jayuk
 */
public interface Jenis 
{
    public String jenis();
}
