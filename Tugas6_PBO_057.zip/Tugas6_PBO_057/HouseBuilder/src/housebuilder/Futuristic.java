package housebuilder;

/**
 *
 * @author Jayuk
 */
public class Futuristic implements Jenis
{

    @Override
    public String jenis() 
    {
        return "Futuristic";
    }
    
}