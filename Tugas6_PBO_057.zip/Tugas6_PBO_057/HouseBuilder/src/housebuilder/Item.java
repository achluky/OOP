package housebuilder;

/**
 *
 * @author Jayuk
 */
public interface Item 
{
    public String nama();
    public Jenis jenis();
    public float price();
}
