package toyfactory;

/**
 *
 * @author Jayuk
 */
public interface Toy 
{
    void product();
}
