package toyfactory;

/**
 *
 * @author Jayuk
 */
public class Boneka implements Toy
{ 
    @Override
    public void product() 
    {
        System.out.println("Boneka");
    }
    
}
