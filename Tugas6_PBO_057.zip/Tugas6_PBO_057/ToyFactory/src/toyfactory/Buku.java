package toyfactory;

/**
 *
 * @author Jayuk
 */
public class Buku implements Toy
{
    @Override
    public void product() 
    {
        System.out.println("Buku");
    }
}
