package toyfactory;

/**
 *
 * @author Jayuk
 */
public class RemoteControl implements Toy
{
    @Override
    public void product() {
        System.out.println("Remote Control");
    }
}
