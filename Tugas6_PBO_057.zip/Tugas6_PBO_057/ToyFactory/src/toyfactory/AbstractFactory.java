package toyfactory;

/**
 *
 * @author Jayuk
 */
public abstract class AbstractFactory 
{
    abstract Toy getProduct(String toy);
}
